import RemoteStorage from './remotestorage';
import Solid from './solid';
/** Opt-in entry point. Use instead of the default entry to enable Solid. */
export declare class RemoteStorageWithSolid extends RemoteStorage {
    static Solid: typeof Solid;
    solid?: Solid;
}
export default RemoteStorageWithSolid;
//# sourceMappingURL=remotestorage-solid.d.ts.map