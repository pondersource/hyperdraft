import type { IStorage } from '@inrupt/solid-client-authn-browser';
/**
 * Storage for the Solid SDK's non-secret login state. Delegate every key
 * unchanged rather than merging undocumented SDK session records together.
 * Tokens and DPoP keys remain in the SDK's separate, in-memory secure store.
 * @internal
 */
export declare class SolidStorage implements IStorage {
    private storage;
    constructor(storage: Storage);
    get(key: string): Promise<string | undefined>;
    set(key: string, value: string): Promise<void>;
    delete(key: string): Promise<void>;
}
export default SolidStorage;
//# sourceMappingURL=solid-storage.d.ts.map