import RemoteStorageWithSolid from './remotestorage-solid';
import LWS from './lws';
import OneDrive from './onedrive';
import NextGraph from './nextgraph';
/** Ponder Source distribution with every implemented backend. */
export declare class RemoteStorageWithAllBackends extends RemoteStorageWithSolid {
    static LWS: typeof LWS;
    static OneDrive: typeof OneDrive;
    static NextGraph: typeof NextGraph;
    static AtomicPlugin: boolean;
}
export default RemoteStorageWithAllBackends;
//# sourceMappingURL=remotestorage-all.d.ts.map