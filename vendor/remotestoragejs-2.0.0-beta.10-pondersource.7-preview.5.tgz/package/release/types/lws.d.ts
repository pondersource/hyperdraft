import { RemoteBase } from './remote';
import type { Remote, RemoteResponse, RemoteSettings } from './remote';
import { discoverLWS } from './lws-discovery';
import LWSOpenID from './lws-openid';
type Discovery = Awaited<ReturnType<typeof discoverLWS>>;
type LWSCredentialProvider = (context: {
    storage: string;
    authorizationServer: string;
    metadata: any;
    interactive?: boolean;
}) => Promise<{
    token: string;
    type: string;
}>;
/** Experimental adapter for LWS, with an rs.js index for server-assigned names.
 * Identity credentials are obtained through an application-supplied provider;
 * Solid-OIDC access tokens must not be reused as LWS access tokens.
 */
declare class LWS extends RemoteBase implements Remote {
    href: string;
    storageURL: string;
    discovery: Discovery;
    credentialProvider: LWSCredentialProvider;
    request: typeof fetch;
    token: string;
    folderETagsAreRecursive: boolean;
    private expires;
    private generation;
    private refreshing;
    private bridged;
    private paths;
    private openID;
    private openIDOptions;
    constructor(rs: any);
    setStorageURL(address: string): void;
    setCredentialProvider(provider: LWSCredentialProvider): void;
    configureOpenID(options: ConstructorParameters<typeof LWSOpenID>[0]): void;
    handleIncomingRedirect(): Promise<boolean>;
    configure(settings: RemoteSettings): void;
    private authenticate;
    connect(): Promise<void>;
    getFileURL(path: string): string;
    private send;
    private conditions;
    private result;
    get(path: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    private read;
    put(path: string, body: XMLHttpRequestBodyInit, contentType: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    delete(path: string, options?: {
        ifMatch?: string;
    }): Promise<RemoteResponse>;
    static isRedirect(url: string): boolean;
    static _rs_init(rs: any): void;
    static _rs_supported(): boolean;
    static _rs_cleanup(rs: any): void;
}
export = LWS;
//# sourceMappingURL=lws.d.ts.map