import { RemoteBase, type Remote, type RemoteResponse, type RemoteSettings } from './remote';
import type RemoteStorage from './remotestorage';
import { type OneDriveRecord } from './onedrive-format';
import { type DocumentRevision } from './document-ledger';
interface Snapshot {
    format: 'pondersource-rs-documents';
    version: 1;
    records: {
        path: string;
        file: OneDriveRecord;
    }[];
}
/** Experimental native wallet backend. Nextgraph owns local persistence and
 * encrypted replication. rs.js exposes its document view; no broker delivery
 * acknowledgement is inferred from an SDK transaction completing locally.
 */
declare class NextGraph extends RemoteBase implements Remote {
    readonly supportsAtomicCreate = false;
    getStorageIdentity(): string;
    folderETagsAreRecursive: boolean;
    deliveryState: 'local' | 'needs-attention';
    requiresReload: boolean;
    collection: string;
    private session;
    private subscription;
    private documents;
    private previousRemote;
    private generation;
    private connecting;
    private resume;
    private queue;
    constructor(rs: RemoteStorage);
    configure(settings: RemoteSettings): void;
    /** Native wallet consent may navigate/reload the app inside Nextgraph. */
    connect(): Promise<void>;
    private open;
    private records;
    get(path: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    private exclusive;
    private commit;
    put(path: string, body: XMLHttpRequestBodyInit, contentType: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    delete(path: string, options?: {
        ifMatch?: string;
    }): Promise<RemoteResponse>;
    /** Both candidates remain durable until an explicit application decision. */
    getConflicts(path: string): DocumentRevision[];
    listConflicts(): {
        path: string;
        revisions: DocumentRevision[];
    }[];
    resolveConflict(path: string, chosenRevision: string, expectedHeads?: string[]): Promise<void>;
    /** Explicit export of this app's local cache only; it never fetches other accounts. */
    exportSnapshot(): Promise<Snapshot>;
    /** Explicit first import. Existing documents are refused and source files stay intact. */
    importSnapshot(snapshot: Snapshot): Promise<{
        path: string;
        statusCode: number;
    }[]>;
    getItemURL(): Promise<undefined>;
    static _rs_supported(): boolean;
    static _rs_init(rs: RemoteStorage): void;
    static _rs_cleanup(rs: RemoteStorage): void;
}
export = NextGraph;
//# sourceMappingURL=nextgraph.d.ts.map