// Reusable utility functions

import type { StorageInfo } from './interfaces/storage_info';

export const logError = (error: string | Error): void => {
  if (typeof (error) === 'string') {
    console.error(error);
  } else {
    console.error(error.message, error.stack);
  }
};

export const globalContext = (typeof (window) !== 'undefined' ? window : (typeof self === 'object' ? self : global));

export const getGlobalContext = (): any => {
  return (typeof (window) !== 'undefined' ? window : (typeof self === 'object' ? self : global));
};

// TODO Remove in favor of modern JS:
// `const mergedObject = { ...obj1, ..obj2 }`
export const extend = (...args): unknown => {
  const target = args[0];
  const sources = Array.prototype.slice.call(args, 1);
  sources.forEach(function (source) {
    for (const key in source) {
      target[key] = source[key];
    }
  });
  return target;
};

export const containingFolder = (path: string): string => {
  if (path === '') {
    return '/';
  }
  if (!path) {
    throw "Path not given!";
  }

  return path.replace(/\/+/g, '/')
    .replace(/[^\/]+\/?$/, '');
};

export const isFolder = (path: string): boolean => {
  return path.slice(-1) === '/';
};

export const isDocument = (path: string): boolean => {
  return !isFolder(path);
};

export const baseName = (path: string): string => {
  const parts = path.split('/');
  if (isFolder(path)) {
    return parts[parts.length - 2] + '/';
  } else {
    return parts[parts.length - 1];
  }
};

export const cleanPath = (path: string): string => {
  return path.replace(/\/+/g, '/')
    .split('/').map(encodeURIComponent).join('/')
    .replace(/'/g, '%27');
};

export const bindAll = (object: object) => {
  for (const key in this) {
    if (typeof (object[key]) === 'function') {
      object[key] = object[key].bind(object);
    }
  }
};

export const equal = (a: any, b: any, seen = []): boolean => {
  let key;

  if (typeof (a) !== typeof (b)) {
    return false;
  }

  if (typeof (a) === 'number' || typeof (a) === 'boolean' || typeof (a) === 'string') {
    return a === b;
  }

  if (typeof (a) === 'function') {
    return a.toString() === b.toString();
  }

  if (a instanceof ArrayBuffer || ArrayBuffer.isView(a) || b instanceof ArrayBuffer || ArrayBuffer.isView(b)) {
    if (!(a instanceof ArrayBuffer || ArrayBuffer.isView(a)) || !(b instanceof ArrayBuffer || ArrayBuffer.isView(b))) { return false; }
    const left = a instanceof ArrayBuffer ? new Uint8Array(a) : new Uint8Array(a.buffer, a.byteOffset, a.byteLength);
    const right = b instanceof ArrayBuffer ? new Uint8Array(b) : new Uint8Array(b.buffer, b.byteOffset, b.byteLength);
    return left.length === right.length && left.every((byte, index) => byte === right[index]);
  }

  // typeof null is 'object'. If either is null, check if they are equal.
  if (a === null || b === null) {
    return a === b;
  }

  // If this point has been reached, a and b are either arrays or objects.

  if (a instanceof Array) {
    if (a.length !== b.length) {
      return false;
    }

    for (let i = 0, c = a.length; i < c; i++) {
      if (!equal(a[i], b[i], seen)) {
        return false;
      }
    }
  } else {
    // Check that keys from a exist in b
    for (key in a) {
      if (a.hasOwnProperty(key) && !(key in b)) {
        return false;
      }
    }

    // Check that keys from b exist in a, and compare the values
    for (key in b) {
      if (!b.hasOwnProperty(key)) {
        continue;
      }

      if (!(key in a)) {
        return false;
      }

      let seenArg;

      if (typeof (b[key]) === 'object') {
        if (seen.indexOf(b[key]) >= 0) {
          // Circular reference, don't attempt to compare this object.
          // If nothing else returns false, the objects match.
          continue;
        }

        seenArg = seen.slice();
        seenArg.push(b[key]);
      }

      if (!equal(a[key], b[key], seenArg)) {
        return false;
      }
    }
  }

  return true;
};

export const deepClone = (obj: any): any => {
  if (obj === undefined) {
    return undefined;
  } else if (typeof structuredClone === 'function') {
    return structuredClone(obj);
  } else if (obj instanceof ArrayBuffer) {
    return obj.slice(0);
  } else if (ArrayBuffer.isView(obj)) {
    const buffer = new Uint8Array(obj.buffer, obj.byteOffset, obj.byteLength).slice().buffer;
    const constructor = obj.constructor as { new(buffer: ArrayBuffer): ArrayBufferView };
    return obj instanceof DataView ? new DataView(buffer) : new constructor(buffer);
  } else if (Array.isArray(obj)) {
    return obj.map(item => deepClone(item));
  } else if (obj && Object.prototype.toString.call(obj) === '[object Object]') {
    const copy = {};
    for (const key of Object.keys(obj)) {
      Object.defineProperty(copy, key, { value: deepClone(obj[key]), enumerable: true, writable: true, configurable: true });
    }
    return copy;
  } else {
    return JSON.parse(JSON.stringify(obj));
  }
};

export const pathsFromRoot = (path: string): string[] => {
  const paths = [path];
  const parts = path.replace(/\/$/, '').split('/');

  while (parts.length > 1) {
    parts.pop();
    paths.push(parts.join('/') + '/');
  }
  return paths;
};

const storageAvailable = (name: 'localStorage' | 'sessionStorage'): boolean => {
  const context = getGlobalContext();

  if (!(name in context)) {
    return false;
  }

  try {
    context[name].setItem('rs-check', '1');
    context[name].removeItem('rs-check');
    return true;
  } catch {
    return false;
  }
};

/** Whether localStorage exists and accepts writes (it can be blocked or full). */
export const localStorageAvailable = (): boolean => storageAvailable('localStorage');

/** Whether sessionStorage exists and accepts writes (it can be blocked or full). */
export const sessionStorageAvailable = (): boolean => storageAvailable('sessionStorage');

/**
 * Extract and parse JSON data from localStorage.
 *
 * @param {string} key - localStorage key
 *
 * @returns {object} parsed object or undefined
 */
export const getJSONFromLocalStorage = (key: string): { [key: string]: any } => {
  const context = getGlobalContext() as Window;

  try {
    return JSON.parse(context.localStorage.getItem(key));
  } catch (e) {
    // no JSON stored
  }
};

/**
 * Decide if data should be treated as binary based on the content (presence of non-printable characters
 * or replacement character) and content-type.
 *
 * @param {string} content - The data
 * @param {string} mimeType - The data's content-type
 *
 * @returns {boolean}
 */
export const shouldBeTreatedAsBinary = (content: string | ArrayBuffer, mimeType: string): boolean => {
  // The `charset=binary` branch is kept for backward compatibility: files uploaded
  // with a release <=2.0.0-beta.9 carry that non-standard suffix in their stored
  // Content-Type. New uploads no longer emit it; the control-char heuristic below
  // handles them.
  const type = (mimeType || '').split(';')[0].trim().toLowerCase();
  if (/charset\s*=\s*binary/i.test(mimeType || '') ||
      /^(image|audio|video)\//.test(type) && type !== 'image/svg+xml' ||
      ['application/pdf', 'application/zip'].includes(type)) {
    return true;
  }
  // XHR returns an ArrayBuffer. Testing that object's string representation
  // misses binary bytes and corrupts them when they are decoded as text.
  const text = typeof content === 'string' ? content : new TextDecoder().decode(content);
  // eslint-disable-next-line no-control-regex
  return /[\x00-\x08\x0E-\x1F\x80-\x9F\uFFFD]/.test(text);
};

/**
 * Strip the legacy `; charset=binary` parameter from a Content-Type.
 *
 * Releases <=2.0.0-beta.9 appended this non-standard parameter to all binary
 * PUTs, so files written back then still carry it in their stored Content-Type
 * forever. We sanitize on read so callers never see it: some browsers refuse
 * to render an `<img>` whose Blob type carries the suffix.
 *
 * Only the `charset=binary` parameter is removed; legitimate parameters like
 * `charset=UTF-8` on `text/html` are preserved.
 *
 * @param {string} mimeType - The raw Content-Type as returned by the server.
 * @returns {string} The Content-Type with any `; charset=binary` removed.
 */
export const stripLegacyCharsetBinary = (mimeType: string | null): string | null => {
  if (!mimeType) {
    return mimeType;
  }
  return mimeType.replace(/\s*;\s*charset=binary\b/i, '');
};

/**
 * Read data from an ArrayBuffer and return it as a string
 * @param {ArrayBuffer} arrayBuffer
 * @param {string} encoding
 * @returns {Promise} Resolves with a string containing the data
 */
export const getTextFromArrayBuffer = (arrayBuffer: ArrayBuffer, encoding): Promise<string | ArrayBuffer> => {
  return new Promise((resolve/*, reject*/) => {
    if (typeof Blob === 'undefined' || typeof FileReader === 'undefined') {
      const buffer = Buffer.from(arrayBuffer);
      resolve(buffer.toString(encoding));
    } else {
      let blob;
      const gc = globalContext as any;
      // TODO fix as BlobBuilder is not available in all browsers
      // @see https://developer.mozilla.org/en-US/docs/Web/API/BlobBuilder
      gc.BlobBuilder = gc.BlobBuilder || gc.WebKitBlobBuilder;
      if (typeof gc.BlobBuilder !== 'undefined') {
        const bb = new gc.BlobBuilder();
        bb.append(arrayBuffer);
        blob = bb.getBlob();
      } else {
        blob = new Blob([arrayBuffer]);
      }

      const fileReader = new FileReader();
      if (typeof fileReader.addEventListener === 'function') {
        fileReader.addEventListener('loadend', function (evt) {
          resolve(evt.target.result);
        });
      } else {
        fileReader.onloadend = function (evt) {
          resolve(evt.target.result);
        };
      }
      fileReader.readAsText(blob, encoding);
    }
  });
};

/**
 * Encode string in base64
 * @param {String} str
 * @returns {String} base64-encoded string
 */
export const toBase64 = (str: string): string => {
  const context = getGlobalContext();
  if ('btoa' in context) {
    return context['btoa'](str);
  } else {
    return Buffer.from(str).toString('base64');
  }
};

/**
 * Whether credentials may be sent to this endpoint: https, or plain http on
 * localhost for development.
 */
export function isSecureEndpoint (url: string): boolean {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }
  if (parsed.protocol === 'https:') {
    return true;
  }
  return parsed.protocol === 'http:' &&
    ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
}

/**
 * The PKCE token endpoint advertised by the server (spec §10.1), or null when
 * it does not advertise the S256 authorization code flow (an authorization
 * endpoint, a token endpoint and the S256 method, all three).
 */
export function pkceTokenURL (info: StorageInfo): string | null {
  const methods = Array.isArray(info.pkceMethods)
    ? info.pkceMethods
    : typeof info.pkceMethods === 'string'
      ? info.pkceMethods.split(/[\s,]+/).filter(Boolean)
      : [];
  return (info.authorizationURL && info.tokenURL && methods.includes('S256')) ? info.tokenURL : null;
}

/**
 * Generates values required for OAuth2 PKCE in a cryptographically secure manner.
 * @param {number} [numChar=128] - length of codeVerifier to generate; from 43 to 128
 *
 * @typedef {Object} PkceValues
 * @property {string} codeVerifier - 43 to 128 chars from the 66-char set
 * @property {string} codeChallenge - verifier hashed & base-64 URL encoded
 * @property {string} state - a separate random value. Should be used to check redirect_uri.
 * @returns PkceValues
 */
export async function generateCodeVerifier(numChar = 128) {
  const randomBytes = new Uint8Array(numChar);
  crypto.getRandomValues(randomBytes);

  const charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
  const randomChar = Array.from(randomBytes).map(byte => charSet[byte % charSet.length]);
  const codeVerifier = randomChar.join('');

  const charsAsBytes = Uint8Array.from(randomChar.map(ch => ch.charCodeAt(0)));
  const sha256hash = await crypto.subtle.digest('SHA-256', charsAsBytes);
  const codeChallenge = base64Urlencode(sha256hash);

  crypto.getRandomValues(randomBytes);
  const stateRandomChar = Array.from(randomBytes).map(byte => charSet[byte % charSet.length]);
  const state = stateRandomChar.join('');

  return {codeVerifier, codeChallenge, state};
}

function base64Urlencode(str) {
  return btoa(String.fromCharCode.apply(null,
      new Uint8Array(str)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
}

/*
 * Apply mixins to an object
 *
 * https://www.typescriptlang.org/docs/handbook/mixins.html
 *
 * @param derivedConstructor Parent object
 * @param constructors Mixins to apply methods from
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function applyMixins(derivedCtor: any, constructors: any[]): void {
  constructors.forEach(baseCtor => {
    Object.getOwnPropertyNames(baseCtor.prototype).forEach(name => {
      Object.defineProperty(
        derivedCtor.prototype,
        name,
        Object.getOwnPropertyDescriptor(baseCtor.prototype, name));
    });
  });
}
