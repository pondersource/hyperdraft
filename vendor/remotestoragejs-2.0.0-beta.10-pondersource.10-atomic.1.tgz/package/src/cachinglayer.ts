import type { ChangeObj } from './interfaces/change_obj';
import type { QueuedRequestResponse } from './interfaces/queued_request_response';
import type { RSEvent } from './interfaces/rs_event';
import type { RSItem, RSNode, RSNodes, ProcessNodes } from './interfaces/rs_node';
import Env from './env';
import EventHandling from './eventhandling';
import config from './config';
import { withCacheTransaction } from './cache-transaction';
import log from './log';
import {
  applyMixins,
  deepClone,
  equal,
  globalContext,
  isDocument,
  isFolder,
  pathsFromRoot,
  stripLegacyCharsetBinary
} from './util';

function getLatest (node: RSNode): RSItem {
  if (typeof (node) !== 'object' || typeof (node.path) !== 'string') {
    return;
  }
  if (isFolder(node.path)) {
    if (node.local && node.local.itemsMap) {
      return node.local;
    }
    if (node.common && node.common.itemsMap) {
      return node.common;
    }
  } else {
    if (node.local) {
      if (node.local.body !== undefined && node.local.body !== false && node.local.contentType) {
        return node.local;
      }
      if (node.local.body === false) {
        return;
      }
    }
    if (node.push) {
      if (node.push.body !== undefined && node.push.body !== false && node.push.contentType) { return node.push; }
      if (node.push.body === false) { return; }
    }
    if (node.common && node.common.body !== undefined && node.common.body !== false && node.common.contentType) {
      return node.common;
    }
  }
}

function isOutdated (nodes: RSNodes, maxAge: number): boolean {
  // Adapters may merge pending writes after database results. Inspect the
  // requested child before its ancestors, regardless of object insertion order.
  for (const path of Object.keys(nodes).sort((a, b) => b.length - a.length)) {
    if (nodes[path] && nodes[path].remote) {
      return true;
    }

    const nodeVersion = getLatest(nodes[path]);

    if (nodeVersion && nodeVersion.timestamp && (new Date().getTime()) - nodeVersion.timestamp <= maxAge) {
      return false;
    } else if (!nodeVersion) {
      return true;
    }
  }
  return true;
}


function makeNode (path: string): RSNode {
  const node: RSNode = {path: path, common: {}};

  if (isFolder(path)) {
    node.common.itemsMap = {};
  }
  return node;
}

function updateFolderNodeWithItemName (node: RSNode, itemName: string): RSNode {
  if (!node.common) {
    node.common = {
      itemsMap: {}
    };
  }
  if (!node.common.itemsMap) {
    node.common.itemsMap = {};
  }
  if (!node.local) {
    node.local = deepClone(node.common);
  }
  if (!node.local.itemsMap) {
    node.local.itemsMap = node.common.itemsMap;
  }
  node.local.itemsMap[itemName] = true;

  return node;
}

/**
 * This module defines functions that are mixed into remoteStorage.local when
 * it is instantiated (currently one of indexeddb.js, localstorage.js, or
 * inmemorystorage.js).
 *
 * All remoteStorage.local implementations should therefore implement
 * this.getNodes, this.setNodes, and this.forAllNodes. The rest is blended in
 * here to create a GPD (get/put/delete) interface which the BaseClient can
 * talk to.
 *
 * @interface
 */

abstract class CachingLayer {
  /** Shared persistent cache identity, used for short cross-tab transactions. */
  readonly sharedCacheId?: string;
  // FIXME
  // this process of updating nodes needs to be heavily documented first, then
  // refactored. Right now it's almost impossible to refactor as there's no
  // explanation of why things are implemented certain ways or what the goal(s)
  // of the behavior are. -slvrbckt (+1 -les)
  private _updateNodesRunning = false;
  private _updateNodesQueued = [];


  // functions that will be overwritten
  // ----------------------------------
  abstract getNodes(paths: string[]): Promise<RSNodes>;

  abstract diffHandler(...args: any[]);

  abstract forAllNodes(cb: (node) => any): Promise<void>;

  abstract setNodes(nodes: RSNodes): Promise<void>;

  /**
   * Broadcast channel, used to inform other tabs about change events
   */
  broadcastChannel: BroadcastChannel;

  constructor () {
    const env = new Env();
    if (env.isBrowser() && !!globalContext["BroadcastChannel"]) {
      this.broadcastChannel = new BroadcastChannel('remotestorage:changes');
      // Listen for change events from other tabs, and re-emit here
      this.broadcastChannel.onmessage = (event: MessageEvent) => {
        this.emitChange(event.data);
      };
    }
  }

  // --------------------------------------------------

  // TODO: improve our code structure so that this function
  // could call sync.queueGetRequest directly instead of needing
  // this hacky third parameter as a callback
  async get (path: string, maxAge: number, queueGetRequest: (path2: string) => Promise<QueuedRequestResponse>): Promise<QueuedRequestResponse> {
    if (typeof (maxAge) === 'number') {
      return this.getNodes(pathsFromRoot(path))
        .then((objs) => {
          const item: RSItem = getLatest(objs[path]);

          if (isOutdated(objs, maxAge)) {
            return queueGetRequest(path);
          } else if (item) {
            return {
              statusCode: 200,
              body: item.body !== undefined && item.body !== false ? item.body : item.itemsMap,
              contentType: stripLegacyCharsetBinary(item.contentType || null)
            };
          } else {
            return { statusCode: 404 };
          }
        });
    } else {
      return this.getNodes([path])
        .then((objs) => {
          const item: RSItem = getLatest(objs[path]);

          if (item) {
            if (isFolder(path)) {
              for (const i in item.itemsMap) {
                // the hasOwnProperty check here is only because our jshint settings require it:
                if (item.itemsMap.hasOwnProperty(i) && item.itemsMap[i] === false) {
                  delete item.itemsMap[i];
                }
              }
            }
            return {
              statusCode: 200,
              body: item.body !== undefined && item.body !== false ? item.body : item.itemsMap,
              contentType: stripLegacyCharsetBinary(item.contentType || null)
            };
          } else {
            return {statusCode: 404};
          }
        });
    }
  }

  async put (path: string, body: string | ArrayBuffer | ArrayBufferView, contentType: string): Promise<QueuedRequestResponse> {
    const paths = pathsFromRoot(path);

    function _processNodes(nodePaths: string[], nodes: RSNodes): RSNodes {
      try {
        for (let i = 0, len = nodePaths.length; i < len; i++) {
          const nodePath = nodePaths[i];
          let node = nodes[nodePath];
          let previous: RSItem;

          if (!node) {
            nodes[nodePath] = node = makeNode(nodePath);
          }

          // Document
          if (i === 0) {
            previous = getLatest(node);
            node.local = {
              body: body,
              contentType: contentType,
              previousBody: (previous ? previous.body : undefined),
              previousContentType: (previous ? previous.contentType : undefined),
            };
          }
          // Folder
          else {
            const itemName = nodePaths[i - 1].substring(nodePath.length);
            node = updateFolderNodeWithItemName(node, itemName);
          }
        }
        return nodes;
      } catch (e) {
        log('[Cachinglayer] Error during PUT', nodes, e);
        throw e;
      }
    }

    return this._updateNodes(paths, _processNodes);
  }

  async delete (path: string, remoteConnected: boolean): Promise<QueuedRequestResponse> {
    const paths = pathsFromRoot(path);

    return this._updateNodes(paths, function (nodePaths, nodes) {
      for (let i = 0, len = nodePaths.length; i < len; i++) {
        const nodePath = nodePaths[i];
        const node = nodes[nodePath];
        let previous;

        if (!node) {
          console.error('Cannot delete non-existing node ' + nodePath);
          continue;
        }

        if (i === 0) {
          // Document
          previous = getLatest(node);
          node.local = {
            body: remoteConnected ? false : undefined,
            previousBody: (previous ? previous.body : undefined),
            previousContentType: (previous ? previous.contentType : undefined),
          };
        } else {
          // Folder
          if (!node.local) {
            node.local = deepClone(node.common);
          }
          const itemName = nodePaths[i - 1].substring(nodePath.length);
          delete node.local.itemsMap[itemName];

          if (Object.getOwnPropertyNames(node.local.itemsMap).length > 0) {
            // This folder still contains other items, don't remove any further ancestors
            break;
          }
        }
      }

      return nodes;
    });
  }

  flush(path: string): Promise<void> {
    return withCacheTransaction(this, () => this._getAllDescendentPaths(path).then((paths: string[]) => {
      return this.getNodes(paths);
    }).then((nodes: RSNodes) => {
      for (const nodePath in nodes) {
        const node = nodes[nodePath];

        if (node && node.common && node.local) {
          this.emitChange({
            path: node.path,
            origin: 'local',
            oldValue: (node.local.body === false ? undefined : node.local.body),
            newValue: (node.common.body === false ? undefined : node.common.body)
          });
        }
        nodes[nodePath] = undefined;
      }

      return this.setNodes(nodes);
    }));
  }

  /**
   * Emit a change event
   */
  emitChange(obj: ChangeObj): void {
    if (config.changeEvents[obj.origin]) {
      this._emit('change', obj);
    }
  }

  fireInitial (): void {
    if (!config.changeEvents.local) { return; }

    this.forAllNodes((node) => {
      if (isDocument(node.path)) {
        const latest = getLatest(node);
        if (latest) {
          this.emitChange({
            path: node.path,
            origin: 'local',
            oldValue: undefined,
            oldContentType: undefined,
            newValue: latest.body,
            newContentType: latest.contentType
          });
        }
      }
    }).then(() => {
      this._emit('local-events-done');
    });
  }

  // TODO add proper type
  onDiff(diffHandler: any) {
    this.diffHandler = diffHandler;
  }

  private _updateNodes(paths: string[], _processNodes: ProcessNodes): Promise<QueuedRequestResponse> {
    return withCacheTransaction(this, () => new Promise((resolve, reject) => {
      this._doUpdateNodes(paths, _processNodes, {
        resolve: resolve,
        reject: reject
      });
    }));
  }

  private async _doUpdateNodes(paths: string[], _processNodes: ProcessNodes, promise): Promise<void> {
    if (this._updateNodesRunning) {
      this._updateNodesQueued.push({
        paths: paths,
        cb: _processNodes,
        promise: promise
      });
      return;
    }
    this._updateNodesRunning = true;

    try {
      let nodes = await this.getNodes(paths);
      const existingNodes = deepClone(nodes);
      const changeEvents = [];

      nodes = _processNodes(paths, nodes);

      for (const path in nodes) {
        const node = nodes[path];
        if (equal(node, existingNodes[path])) {
          delete nodes[path];
        } else if (isDocument(path)) {
          if (
            !equal(node.local.body, node.local.previousBody) ||
            node.local.contentType !== node.local.previousContentType
          ) {
            changeEvents.push({
              path: path,
              origin: 'window',
              oldValue: node.local.previousBody,
              newValue: node.local.body === false ? undefined : node.local.body,
              oldContentType: node.local.previousContentType,
              newContentType: node.local.contentType
            });
          }
          if (node.local.body === undefined) {
            // no remote connected, remove deleted node from cache immediately
            nodes[path] = undefined;
          } else {
            delete node.local.previousBody;
            delete node.local.previousContentType;
          }
        }
      }

      await this.setNodes(nodes);
      this._emitChangeEvents(changeEvents);

      promise.resolve({ statusCode: 200 });
    } catch (err) {
      promise.reject(err);
    }

    this._updateNodesRunning = false;
    const nextJob = this._updateNodesQueued.shift();
    if (nextJob) {
      await this._doUpdateNodes(nextJob.paths, nextJob.cb, nextJob.promise);
    }
  }

  private _emitChangeEvents(events: RSEvent[]) {
    for (let i = 0, len = events.length; i < len; i++) {
      const change = events[i];

      this.emitChange(change);

      if (this.diffHandler) {
        this.diffHandler(change.path);
      }

      if (!!this.broadcastChannel && change.origin === "window") {
        this.broadcastChannel.postMessage(change); // Broadcast to other tabs
      }
    }
  }

  private _getAllDescendentPaths(path: string) {
    if (isFolder(path)) {
      return this.getNodes([path]).then((nodes) => {
        const allPaths = [path];
        const latest = getLatest(nodes[path]);

        const itemNames = Object.keys(latest.itemsMap);
        const calls = itemNames.map((itemName) => {
          return this._getAllDescendentPaths(path + itemName).then((paths) => {
            for (let i = 0, len = paths.length; i < len; i++) {
              allPaths.push(paths[i]);
            }
          });
        });
        return Promise.all(calls).then(() => {
          return allPaths;
        });
      });
    } else {
      return Promise.resolve([path]);
    }
  }

  // treated as private but made public for unit testing
  _getInternals() {
    return {
      getLatest: getLatest,
      makeNode: makeNode,
      isOutdated: isOutdated
    };
  }
}


interface CachingLayer extends EventHandling {}
applyMixins(CachingLayer, [EventHandling]);

export = CachingLayer;
