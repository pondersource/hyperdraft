import { type AtomicSDK } from './atomic-client';
import { RemoteBase, type Remote, type RemoteResponse, type RemoteSettings } from './remote';
import type RemoteStorage from './remotestorage';
/** Use immutable, app-scoped Atomic document revisions with the signed-in user's approved app key. */
declare class Atomic extends RemoteBase implements Remote {
    /** Configure with an application-local, version-pinned SDK loader before creating RemoteStorage. */
    static loadSDK?: () => Promise<AtomicSDK>;
    readonly supportsAtomicCreate = false;
    readonly folderETagsAreRecursive = false;
    private connection?;
    private client?;
    private previousRemote?;
    private attempt?;
    private lifetime?;
    private queue;
    constructor(rs: RemoteStorage);
    getStorageIdentity(): string;
    configure(settings: RemoteSettings): void;
    /** Return the approval link without exposing the app-owned private key. */
    requestAppKey(server: string, options: {
        drive: string;
        signal: AbortSignal;
    }): Promise<{
        publicKey: string;
        grantUrl: string;
        waitForGrant: () => Promise<void>;
    }>;
    private completeConnection;
    private activate;
    private restore;
    private check;
    private list;
    get(path: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    private conflict;
    private write;
    put(path: string, body: XMLHttpRequestBodyInit, contentType: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    delete(path: string, options?: {
        ifMatch?: string;
    }): Promise<RemoteResponse>;
    getItemURL(): Promise<undefined>;
    static _rs_supported(): boolean;
    static _rs_init(rs: RemoteStorage): void;
    private restoreSession;
    static _rs_cleanup(rs: RemoteStorage): Promise<void>;
}
export = Atomic;
//# sourceMappingURL=atomic.d.ts.map