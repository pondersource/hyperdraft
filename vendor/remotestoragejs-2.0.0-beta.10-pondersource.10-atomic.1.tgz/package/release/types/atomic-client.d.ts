import { DocumentRevision } from './document-ledger';
interface AtomicResource {
    subject: string;
    error?: Error;
    get(property: string): unknown;
    getSubjects(property: string): string[];
    hasClasses(subject: string): boolean;
    save(): Promise<string>;
}
interface AtomicAgent {
    subject: string;
    getPublicKey(): Promise<string>;
}
/** Structural interface for the pinned, application-local Atomic SDK build. */
export interface AtomicSDK {
    Agent: {
        fromCryptoKeyPair(keys: CryptoKeyPair, subject?: string): AtomicAgent;
    };
    Client: new (request: typeof fetch) => {
        fetchResourceHTTP(subject: string, options: {
            serverURL: string;
        }): Promise<{
            resource: AtomicResource;
        }>;
        postCommit(commit: object, endpoint: string): Promise<object>;
    };
    Store: new (options: {
        agent: AtomicAgent;
        serverUrl: string;
        noServer: boolean;
        requireOnlineWrites: boolean;
        commitTransport(commit: object): Promise<object>;
    }) => {
        addResource(resource: AtomicResource): void;
        newResource(options: {
            parent: string;
            propVals: Record<string, string>;
        }): Promise<AtomicResource>;
    };
    LoroLoader: {
        initializeLoro(): Promise<unknown>;
    };
    agentSubjectFromPublicKey(key: string): {
        subject: string;
    };
    connectAgentUrl(origin: string, options: {
        publicKey: string;
        name: string;
        write: boolean;
        targets: string[];
    }): string;
    decodeB64(encoded: string): Uint8Array;
    decodeGenesisCert(encoded: Uint8Array): unknown;
    verifyGenesisCert(certificate: unknown, key: string): Promise<boolean>;
    genesisSignerDid(certificate: unknown): string;
    signRequest(url: string, agent: AtomicAgent, headers: HeadersInit): Promise<HeadersInit>;
    server: {
        classes: {
            drive: string;
        };
    };
}
export interface AtomicConnection {
    drive: string;
    node: string;
    agent: string;
    keyPair: CryptoKeyPair;
}
export declare function atomicOrigin(value: string): string;
export declare function atomicDrive(value: string): string;
export declare class AtomicGrantPending extends Error {
}
export declare function atomicClient(sdk: AtomicSDK, connection: AtomicConnection, namespace: string, signal?: AbortSignal): Promise<{
    grant: () => Promise<AtomicResource>;
    readRevisions(): Promise<DocumentRevision[]>;
    append(revision: DocumentRevision): Promise<void>;
}>;
export {};
//# sourceMappingURL=atomic-client.d.ts.map