import { RemoteBase, type Remote, type RemoteResponse, type RemoteSettings } from './remote';
import type RemoteStorage from './remotestorage';
import { type OneDriveRecord } from './onedrive-format';
import { type DocumentRevision } from './document-ledger';
interface Snapshot {
    format: 'pondersource-rs-documents';
    version: 1;
    records: {
        path: string;
        file: OneDriveRecord;
    }[];
}
interface RecoverySnapshot {
    format: 'pondersource-nextgraph-revisions';
    version: 1;
    store: string;
    collection: string;
    records: DocumentRevision[];
}
interface CacheRecoveryCandidate {
    path: string;
    source: string;
    revision?: string;
    deleted: boolean;
    bodyUnavailable?: boolean;
    file?: OneDriveRecord;
}
/** Experimental native wallet backend. An append-only IndexedDB journal owns
 * durable local recovery; the native SDK owns encrypted replication. Neither
 * local journal completion nor SDK completion acknowledges broker delivery.
 */
declare class NextGraph extends RemoteBase implements Remote {
    private walletURL;
    /** Wallet frontend origin; not the address of a broker or a private store. */
    getWalletURL(): string;
    readonly supportsAtomicCreate = false;
    getStorageIdentity(): string;
    folderETagsAreRecursive: boolean;
    deliveryState: 'local' | 'needs-attention';
    requiresReload: boolean;
    collection: string;
    private session;
    private subscription;
    private documents;
    private journal;
    private archived;
    private previousRemote;
    private generation;
    private connecting;
    private resume;
    private queue;
    private coordinatedSelection;
    private resuming;
    private nextResume;
    private networkResume;
    constructor(rs: RemoteStorage);
    configure(settings: RemoteSettings): void;
    /** Native wallet consent may navigate/reload the app inside Nextgraph. */
    connect(walletURL?: string): Promise<void>;
    private guardUnassignedCache;
    private open;
    private records;
    private nativeRecords;
    private refresh;
    private tryResume;
    /** Reopen the same native collection when the SDK's graph becomes available.
     * Journal replay uses the original IDs and only the SDK's own write API.
     * No new collection, direct broker queue or delivery acknowledgement is made.
     */
    resumeNative(): Promise<boolean>;
    get(path: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    private exclusive;
    private publish;
    put(path: string, body: XMLHttpRequestBodyInit, contentType: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    delete(path: string, options?: {
        ifMatch?: string;
    }): Promise<RemoteResponse>;
    /** Both candidates remain durable until an explicit application decision. */
    getConflicts(path: string): DocumentRevision[];
    listConflicts(): {
        path: string;
        revisions: DocumentRevision[];
    }[];
    resolveConflict(path: string, chosenRevision: string, expectedHeads?: string[]): Promise<void>;
    /** Export every accessible immutable version and tombstone from this selected
     * native account/collection. This never fetches another account or deletes data.
     */
    exportRecovery(): Promise<RecoverySnapshot>;
    importRecovery(snapshot: RecoverySnapshot): Promise<void>;
    /** Preserve every accessible old cache candidate without guessing its native
     * account/collection. No migration, remote read or deletion is performed.
     */
    exportCacheRecovery(): Promise<{
        format: 'pondersource-rs-cache-recovery';
        version: 1;
        candidates: CacheRecoveryCandidate[];
    }>;
    /** Explicit export of this app's local cache only; it never fetches other accounts. */
    exportSnapshot(): Promise<Snapshot>;
    /** Explicit first import. Existing documents are refused and source files stay intact. */
    importSnapshot(snapshot: Snapshot): Promise<{
        path: string;
        statusCode: number;
    }[]>;
    getItemURL(): Promise<undefined>;
    static _rs_supported(): boolean;
    static _rs_init(rs: RemoteStorage): void;
    static _rs_cleanup(rs: RemoteStorage): void;
}
export = NextGraph;
//# sourceMappingURL=nextgraph.d.ts.map