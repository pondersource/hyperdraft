/** Compare equivalent HTTP spellings, keeping malformed/ambiguous values opaque. */
export declare function equalContentTypes(left: string | undefined, right: string | undefined): boolean;
//# sourceMappingURL=content-type.d.ts.map