import type { RSNode } from './interfaces/rs_node';
export declare class BinaryCacheError extends Error {
}
/** Text-only rows retain their legacy representation. Binary rows use an outer
 * envelope, so arbitrary JSON body objects cannot collide with binary markers.
 */
export declare function serializeCacheNode(node: RSNode): string;
export declare function deserializeCacheNode(text: string): RSNode | undefined;
//# sourceMappingURL=cache-serialization.d.ts.map