export declare function discoverLWS(address: string, { fetch: request, signal }?: {
    fetch?: typeof fetch;
    signal?: AbortSignal;
}): Promise<{
    storage: any;
    root: string;
    authorizationServers: any[];
}>;
//# sourceMappingURL=lws-discovery.d.ts.map