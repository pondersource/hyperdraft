import { type DocumentRevision } from './document-ledger';
export interface JournalChange<T> {
    value: T;
    append?: DocumentRevision[];
}
/** Validate a complete union before any write. Duplicate immutable IDs must
 * identify exactly the same JSON, including fields this adapter does not use.
 */
export declare function mergeJournalRecords(...sources: DocumentRevision[][]): DocumentRevision[];
/** This journal is a durable readback/recovery archive, not a broker queue.
 * It never deletes revisions or changes the SDK's session/peer sequence data.
 */
export declare class NextGraphJournal {
    readonly store: string;
    readonly collection: string;
    constructor(store: string, collection: string);
    static collections(store: string): Promise<string[]>;
    /** Read heads, check preconditions, validate union and append within one short
     * read/write transaction. No network or native SDK operation runs under it.
     * Promise settlement follows the actual terminal commit/abort event.
     */
    transact<T>(native: DocumentRevision[], work: (records: DocumentRevision[]) => JournalChange<T>, registerCollection?: boolean): Promise<{
        value: T;
        records: DocumentRevision[];
    }>;
}
//# sourceMappingURL=nextgraph-journal.d.ts.map