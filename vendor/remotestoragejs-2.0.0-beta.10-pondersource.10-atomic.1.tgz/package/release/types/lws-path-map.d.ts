type Send = (url: string, init?: RequestInit) => Promise<Response>;
type Index = {
    url: string;
    revision: string;
    entries: Record<string, string>;
};
/** A pod-side CAS index for rs.js names and server-assigned LWS resource IDs.
 * No access tokens or file contents are stored in the index. An ambiguous index
 * or an interrupted non-idempotent POST fails closed rather than being retried.
 */
declare class LWSPathMap {
    cache: Index;
    private writes;
    private storage;
    private root;
    private send;
    constructor(storage: string, root: string, send: Send);
    private resource;
    rootItems(): Promise<any[]>;
    private read;
    private indexCandidates;
    load(): Promise<Index>;
    private body;
    private created;
    private ensure;
    private change;
    create(path: string, body: BodyInit, contentType: string, expected?: string): Promise<Response>;
    forget(path: string, url: string): Promise<void>;
    lookup(path: string): string;
    isInternal(url: string): boolean;
    listing(path: string): Promise<Record<string, any>>;
}
export = LWSPathMap;
//# sourceMappingURL=lws-path-map.d.ts.map