import type RemoteStorage from './remotestorage';
import type { Solid } from './solid';
/** Resource notifications with reconnect/renewal recovery and polling for unwatched paths. @internal */
export declare class SolidNotifications {
    private rs;
    private solid;
    private active;
    private watches;
    private controllers;
    private service?;
    private features;
    private discoveryRetryAt;
    private timer?;
    private scheduled?;
    private reconciling;
    private again;
    private recovery;
    private lastRecovery;
    private recoveryQueue;
    private recoveryTimer?;
    constructor(rs: RemoteStorage, solid: Solid);
    /** Only suppress routine polling after onopen has queued recovery, until renewal is due. */
    hasActiveSubscription(path: string): boolean;
    private onSync;
    private onOnline;
    private onVisible;
    start(): void;
    private schedule;
    /** Reconcile subscriptions with the current cache, not every resource on the pod. */
    private reconcile;
    /** Pace foreground/online recovery; exact live notifications remain immediate. */
    private drainRecovery;
    private request;
    private discover;
    private current;
    private subscribe;
    private receive;
    private failed;
    private close;
    stop(): Promise<void>;
}
//# sourceMappingURL=solid-notifications.d.ts.map