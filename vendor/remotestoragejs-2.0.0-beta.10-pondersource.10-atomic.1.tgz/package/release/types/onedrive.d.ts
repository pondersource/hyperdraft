import { RemoteBase, type Remote, type RemoteResponse, type RemoteSettings } from './remote';
import type RemoteStorage from './remotestorage';
/** Experimental OneDrive app-folder backend. MSAL owns PKCE and token renewal.
 * Uses a shared OAuth application registration to share data between app origins.
 * Public rs.js paths remain private: getItemURL never grants sharing permission.
 */
declare class OneDrive extends RemoteBase implements Remote {
    readonly supportsAtomicCreate = true;
    getStorageIdentity(): string;
    folderETagsAreRecursive: boolean;
    clientId: string;
    private redirectUri;
    request: typeof fetch;
    private auth;
    private initialized;
    private account;
    private root;
    private generation;
    private previousRemote;
    constructor(rs: RemoteStorage);
    /** Configure a public Microsoft Entra SPA registration, never a client secret. */
    setClientId(clientId: string, redirectUri?: string): void;
    private initializeAuth;
    configure(settings: RemoteSettings): void;
    /** User gesture required: opens Microsoft's account chooser in a popup. */
    connect(): Promise<void>;
    private send;
    private assertGeneration;
    private setOnline;
    private itemPath;
    private metadata;
    get(path: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    private ensureParents;
    put(path: string, body: XMLHttpRequestBodyInit, contentType: string, options?: {
        ifMatch?: string;
        ifNoneMatch?: string;
    }): Promise<RemoteResponse>;
    delete(path: string, options?: {
        ifMatch?: string;
    }): Promise<RemoteResponse>;
    /** OneDrive records are private; connection must never publish them implicitly. */
    getItemURL(): Promise<undefined>;
    static isRedirect(url: string): boolean;
    static _rs_init(rs: RemoteStorage): void;
    static _rs_supported(): boolean;
    static _rs_cleanup(rs: RemoteStorage): void;
}
export = OneDrive;
//# sourceMappingURL=onedrive.d.ts.map