type Options = {
    issuer: string;
    clientId: string;
    redirectUri: string;
    idTokenSigningAlg?: string;
};
type Context = {
    storage: string;
    storageURL: string;
    authorizationServer: string;
    interactive?: boolean;
};
declare class LWSOpenID {
    private options;
    private credential;
    private epoch;
    constructor(options: Options);
    private library;
    static isRedirect(url: string): boolean;
    private metadata;
    get(context: Context): Promise<{
        token: string;
        type: string;
    }>;
    handleIncomingRedirect(url?: string): Promise<Context>;
    cancelPending(): void;
    clear(): void;
}
export = LWSOpenID;
//# sourceMappingURL=lws-openid.d.ts.map