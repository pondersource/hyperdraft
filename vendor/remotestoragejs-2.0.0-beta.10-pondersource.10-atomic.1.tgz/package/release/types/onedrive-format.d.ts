/** Versioned, single-item records preserve MIME types and arbitrary rs.js names.
 * One Graph item is one atomic revision; there are no independently updated sidecars.
 */
export interface OneDriveRecord {
    version: 1;
    contentType: string;
    data: string;
}
export declare function base64url(bytes: Uint8Array): string;
export declare function unbase64url(value: string): Uint8Array;
export declare function encodeName(name: string): string;
export declare function decodeName(name: string): string | undefined;
export declare function pathSegments(path: string): string[];
export declare function encodeRecord(body: XMLHttpRequestBodyInit, contentType: string): Promise<string>;
export declare function decodeRecord(value: unknown): {
    body: any;
    contentType: string;
};
//# sourceMappingURL=onedrive-format.d.ts.map