/**
 * Hold the cache mutation queue only while updating local state. Network
 * requests must remain outside it so that offline edits never wait for HTTP.
 *
 * @internal
 */
export declare function withCacheTransaction<T>(cache: object, work: () => Promise<T>): Promise<T>;
//# sourceMappingURL=cache-transaction.d.ts.map