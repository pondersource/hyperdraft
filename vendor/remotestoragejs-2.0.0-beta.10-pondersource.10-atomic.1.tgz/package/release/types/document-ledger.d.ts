import type { OneDriveRecord } from './onedrive-format';
/** Immutable revisions stored in separate CRDT map keys. Byte strings themselves
 * are not mergeable: concurrent heads remain explicit until the user resolves them.
 */
export interface DocumentRevision {
    version: 1;
    id: string;
    path: string;
    parents: string[];
    created: number;
    deleted: boolean;
    file?: OneDriveRecord;
}
export declare function validateDocumentPath(path: string): void;
export declare function readLedger(root: Record<string, unknown>): DocumentRevision[];
export declare function documentHeads(records: DocumentRevision[], path: string): DocumentRevision[];
export declare function documentRevision(path: string, parents: DocumentRevision[], file?: OneDriveRecord): DocumentRevision;
//# sourceMappingURL=document-ledger.d.ts.map