/** Public wallet origin, carried in the app URL across storage partitions. */
export declare const DEFAULT_WALLET_URL = "https://nextgraph.net";
export declare const WALLET_PARAMETER = "rs-nextgraph-wallet";
export declare function normalizeWalletURL(value: string): string;
export declare function requestedWalletURL(): string | undefined;
export declare function rememberedWalletURL(): string | undefined;
export declare function rememberWalletURL(origin: string): void;
export declare function forgetWalletHandoff(): void;
//# sourceMappingURL=nextgraph-wallet.d.ts.map