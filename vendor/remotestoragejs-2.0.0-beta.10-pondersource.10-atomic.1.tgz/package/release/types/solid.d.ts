import { Session } from '@inrupt/solid-client-authn-browser';
import type RemoteStorage from './remotestorage';
import { RemoteBase } from './remote';
import type { Remote, RemoteResponse, RemoteSettings } from './remote';
type Conditions = {
    ifMatch?: string;
    ifNoneMatch?: string;
};
/**
 * Solid storage adapter, included only in the optional Solid entry point.
 * Login uses the Inrupt browser SDK; file operations use its authenticated
 * fetch so HTTP preconditions and ETags retain their server-side meaning.
 * Based on the Solid adapter contributed in PR #1319.
 */
export declare class Solid extends RemoteBase implements Remote {
    readonly supportsAtomicCreate = true;
    getStorageIdentity(): string;
    readonly folderETagsAreRecursive = false;
    readonly minRefreshInterval = 60000;
    authURL: string | null;
    podURLs: string[] | null;
    selectedPodURL: string | null;
    session: Session;
    private active;
    private appHash;
    private appPath;
    private notifications?;
    private notificationCleanup?;
    /** Whether an open, unexpired notification channel covers this exact path. @internal */
    hasActiveSubscription(path: string): boolean;
    private startNotifications;
    private stopNotifications;
    constructor(rs: RemoteStorage);
    private saveSettings;
    /** @internal */
    configure(settings: RemoteSettings): void;
    /** Set the user's Solid identity provider before calling connect(). */
    setAuthURL(authURL: string): void;
    /** Available pods after authentication, including an empty array for no pods. */
    getPodURLs(): string[] | null;
    /** Currently selected pod, or null while pod selection is pending. */
    getPodURL(): string | null;
    /** Select the initial discovered pod. Disconnect before changing or clearing it. */
    setPodURL(podURL: string | null): void;
    /** Start browser login. Register pod-not-selected and error listeners first. */
    connect(): Promise<void>;
    /** The authenticated Inrupt session, or null before login completes. */
    getSession(): Session | null;
    /** Derive a resource URL within the selected pod. */
    getFileURL(path: string): string;
    /** Resource URL; public-scope files are shared read-only before returning. */
    getItemURL(path: string): Promise<string | undefined>;
    private setPublicAccess;
    private request;
    private conditions;
    private validator;
    private result;
    private requireRevision;
    private getFolder;
    /** Read a file or list a container, preserving binary content and revisions. */
    get(path: string, options?: Conditions): Promise<RemoteResponse>;
    /** Write with atomic server-side If-Match/If-None-Match preconditions. */
    put(path: string, body: XMLHttpRequestBodyInit, contentType: string, options?: Conditions): Promise<RemoteResponse>;
    /** Delete with an atomic server-side If-Match precondition. */
    delete(path: string, options?: Conditions): Promise<RemoteResponse>;
    private restore;
    /** @internal */
    static _rs_supported(): boolean;
    /** @internal */
    static _rs_init(rs: RemoteStorage): Promise<void>;
    /** @internal */
    static _rs_cleanup(rs: RemoteStorage): Promise<void>;
}
export default Solid;
//# sourceMappingURL=solid.d.ts.map