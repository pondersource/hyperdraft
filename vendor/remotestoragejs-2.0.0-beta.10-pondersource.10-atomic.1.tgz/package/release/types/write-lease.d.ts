export interface WriteLease {
    release(): void;
}
/** A browser-owned lease ends automatically when its document dies.
 * Acquire outside the short cache transaction; offline edits never take it.
 */
export declare function acquireWriteLease(cacheId: string | undefined, destination: string | undefined, path: string): Promise<WriteLease | undefined>;
//# sourceMappingURL=write-lease.d.ts.map