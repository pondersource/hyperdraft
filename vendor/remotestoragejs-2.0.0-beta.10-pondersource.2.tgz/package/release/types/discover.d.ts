import type { StorageInfo } from './interfaces/storage_info';
/**
 * This function deals with the Webfinger lookup, discovering a connecting
 * user's storage details.
 *
 * @param userAddress - user@host or URL
 *
 * @returns A promise for an object with the following properties.
 *          href - Storage base URL,
 *          storageApi - RS protocol version,
 *          authURL - implicit-flow OAuth URL, if advertised,
 *          authorizationURL - PKCE authorization endpoint, if advertised,
 *          tokenURL - PKCE token endpoint, if advertised,
 *          pkceMethods - supported PKCE code_challenge methods, if advertised,
 *          properties - Webfinger link properties
 **/
declare const Discover: {
    (userAddress: string): Promise<StorageInfo>;
    DiscoveryError(message: any): void;
    _rs_init(): void;
    _rs_supported(): boolean;
    _rs_cleanup(): void;
};
export = Discover;
//# sourceMappingURL=discover.d.ts.map