export type StorageInfo = {
    href: string;
    storageApi: string;
    /** Implicit-flow authorization endpoint; absent from PKCE-only records. */
    authURL?: string;
    properties: object;
    userAddress?: string;
    /** PKCE token endpoint (spec §10.1, rfc6749#section-3.2), when advertised. */
    tokenURL?: string;
    /** Authorization endpoint (spec §10.1, rfc6749#section-3.1), when advertised. */
    authorizationURL?: string;
    /**
     * PKCE code_challenge methods (spec §10.1, rfc7636), e.g. "S256". The spec
     * says a string; an array is tolerated too.
     */
    pkceMethods?: string | string[];
};
//# sourceMappingURL=storage_info.d.ts.map